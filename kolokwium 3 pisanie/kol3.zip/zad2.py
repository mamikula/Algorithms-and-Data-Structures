from zad2testy import runtests

class BNode:
    def __init__( self, value ):
        self.left = None
        self.right = None
        self.parent = None
        self.value = value


def cutthetree(T):
    """tu prosze wpisac wlasna implementacje"""

    
runtests(cutthetree)


