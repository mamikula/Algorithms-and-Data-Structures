from zad3testy import runtests
from zad3EK    import edmonds_karp

def BlueAndGreen(T, K, D):
    # tu prosze wpisac wlasna implementacje
    return 0

runtests( BlueAndGreen ) 
