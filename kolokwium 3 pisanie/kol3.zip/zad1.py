from zad1testy import runtests


def keep_distance(M, x, y, d):
    # tu prosze wpisac wlasna implementacje
    return None


runtests( keep_distance )